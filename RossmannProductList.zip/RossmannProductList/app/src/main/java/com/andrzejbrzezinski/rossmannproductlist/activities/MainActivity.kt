package com.andrzejbrzezinski.rossmannproductlist.activities

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.andrzejbrzezinski.rossmannproductlist.databinding.ActivityMainBinding
import com.andrzejbrzezinski.rossmannproductlist.filmpackage.activities.FilmsActivity
import com.andrzejbrzezinski.rossmannproductlist.itempackage.productlistpackage.activities.ProductListActivity


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.Productlstbt.setOnClickListener {

            val intent = Intent(binding.root.context, ProductListActivity::class.java)
            binding.root.context.startActivity(intent)

        }

        binding.Filmlstbt.setOnClickListener {
            val intent = Intent(binding.root.context, FilmsActivity::class.java)
            binding.root.context.startActivity(intent)

        }






        /*var retrofit: Retrofit = Retrofit.Builder()
            .baseUrl("https://v5stg.rossmann.pl/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val productApi: ProductApi = retrofit.create(ProductApi::class.java)*/




        //viewModel.loadProductsIfNeeded(pagenb)
        //loadProducts(pagenb)

        /*binding.nextPageButton.setOnClickListener {

            //loadProducts(productApi)
            viewModel.loadProducts()
        }
*/



        /*
        productApi.productList(pagenb).enqueue(object : Callback<ProductResponse> {
            override fun onResponse(call: Call<ProductResponse>, response: Response<ProductResponse>) {


                    //Toast.makeText(this@MainActivity, response.body()?.data?.toString(), Toast.LENGTH_SHORT).show()
                val map = response.body()?.data?.products?.map{
                        Productdetails(
                            it.name,
                            it.pictures.first().medium
                        )
                    }?: listOf()
                    //Toast.makeText(this@MainActivity, map.toString(), Toast.LENGTH_SHORT).show()

                  /*  response.body()?.data?.products?.forEach {
                        Log.i("product", it.toString())
                    }*/

                productAdapter.submitList(map)

            }

            override fun onFailure(call: Call<ProductResponse>, t: Throwable) {
                t.printStackTrace()
            }
        })
*/



    }


   /* private fun loadProducts(productApi:ProductApi){
        lifecycleScope.launch() {
            try {
                val response = productApi.productList(pagenb)
                if (response.isSuccessful) {
                    val map = response.body()?.data?.products?.map {
                        Productdetails(
                            it.name,
                            it.price,
                            it.caption,
                            it.pictures.firstOrNull()?.medium


                        )
                    } ?: listOf()

                        if(pagenb==1)
                            productAdapter.submitList(map)
                        else{
                            val currentProducts = productAdapter.currentList.toMutableList()
                            currentProducts.addAll(map)
                            productAdapter.submitList(currentProducts)
                        }

                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }}
*/


}


