package com.andrzejbrzezinski.rossmannproductlist.filmpackage.activities

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity

import com.andrzejbrzezinski.rossmannproductlist.databinding.ActivityFilmsBinding
import com.google.firebase.analytics.ktx.analytics


import com.google.firebase.ktx.Firebase


class FilmsActivity : AppCompatActivity() {
    private lateinit var binding : ActivityFilmsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityFilmsBinding.inflate(layoutInflater)
        setContentView(binding.root)




    }
}