package com.andrzejbrzezinski.rossmannproductlist

import java.io.Serializable

data class Productdetails(
    val name: String?,
    val price: String?,
    val caption: String?,
    val id: Int,
    val image: String?


)

data class Productdetailstwo(
    val availableQuantity: String?
)

data class CombinedData(val productdetails:Productdetails, val productdetailstwo:Productdetailstwo)

data class Productdetailsvdwa(
    val name: String?,
    val price: String?,
    val caption: String?,
    val id: Int,
    val image: List<Pictures>


)

data class ProductHtml(
    val html: String?
)

data class CombinedProductDetails(val productdetailsvdwa:Productdetailsvdwa, val producthtml: ProductHtml?)